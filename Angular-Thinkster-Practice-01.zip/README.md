# typescript-dtbrqd

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/typescript-dtbrqd)